if ( $args.Length -eq 0 ) {
    Write-Error '����������܂���'
    exit
}
$files = Get-ChildItem ".\$Args"

foreach ($f in $files){
        $exefile =  $f.FullName
        #�g����xlsx�ȊO�̓X�L�b�v
        if((Split-Path -Path $exefile -Leaf).Split(".")[1] -ne "xlsx"){
            continue
        }
    if (Test-Path $exefile) {
        $datetime = Get-Date -Format "yyyyMMddHHmmss"
        $excel = New-Object -ComObject Excel.Application
        $excel.Visible = $false

        $curDir = Get-Location

        # �g���q�ύX
        $filename = [System.IO.Path]::GetFileNameWithoutExtension($exefile)   
        $newpdfd = (get-item $exefile ).Directory.FullName
        $newpdfilename ="$newpdfd\$filename.pdf"
    try {
        $book = $excel.Workbooks.Open($exefile)
        # PDF
        $book.ExportAsFixedFormat([Microsoft.Office.Interop.Excel.XlFixedFormatType]::xlTypePDF, $newpdfilename)
        Write-Host $newpdfilename

        $book.Close($false)
    }
        catch {
            Write-Error '�G���[���������܂���'
        }
        finally {
            $excel.Quit()
            $excel = $null
            [GC]::Collect()
        }
    }else {
        Write-Error '�t�@�C����������܂���'
    }
}